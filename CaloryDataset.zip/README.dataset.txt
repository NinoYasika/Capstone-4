# Calory > 2024-07-11 10:20am
https://universe.roboflow.com/ayu-asipq/calory

Provided by a Roboflow user
License: CC BY 4.0

